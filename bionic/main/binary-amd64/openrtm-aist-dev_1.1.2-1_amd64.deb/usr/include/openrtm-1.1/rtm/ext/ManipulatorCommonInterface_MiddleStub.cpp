// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ManipulatorCommonInterface_MiddleStub.cpp 
 * @brief ManipulatorCommonInterface_Middle client stub wrapper code
 * @date Fri Nov  9 17:05:25 2018 
 *
 */

#include "ManipulatorCommonInterface_MiddleStub.h"

#if   defined ORB_IS_TAO
#  include "ManipulatorCommonInterface_MiddleC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "ManipulatorCommonInterface_MiddleSK.cc"
#  include "ManipulatorCommonInterface_MiddleDynSK.cc"
#elif defined ORB_IS_MICO
#  include "ManipulatorCommonInterface_Middle.cc"
#elif defined ORB_IS_ORBIT2
#  include "ManipulatorCommonInterface_Middle-cpp-stubs.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "ManipulatorCommonInterface_Middle-common.c"
#  include "ManipulatorCommonInterface_Middle-stubs.c"
#else
#  error "NO ORB defined"
#endif

// end of ManipulatorCommonInterface_MiddleStub.cpp
