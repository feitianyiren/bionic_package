// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file CameraCommonInterfaceStub.cpp 
 * @brief CameraCommonInterface client stub wrapper code
 * @date Thu Nov  1 18:08:04 2018 
 *
 */

#include "CameraCommonInterfaceStub.h"

#if   defined ORB_IS_TAO
#  include "CameraCommonInterfaceC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "CameraCommonInterfaceSK.cc"
#  include "CameraCommonInterfaceDynSK.cc"
#elif defined ORB_IS_MICO
#  include "CameraCommonInterface.cc"
#elif defined ORB_IS_ORBIT2
#  include "CameraCommonInterface-cpp-stubs.cc"
#elif defined ORB_IS_RTORB
#  include "OpenRTM-aist-decls.h"
#  include "CameraCommonInterface-common.c"
#  include "CameraCommonInterface-stubs.c"
#else
#  error "NO ORB defined"
#endif

// end of CameraCommonInterfaceStub.cpp
